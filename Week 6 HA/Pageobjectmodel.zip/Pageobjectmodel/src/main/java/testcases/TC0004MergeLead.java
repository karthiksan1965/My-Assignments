package testcases;

import org.testng.annotations.Test;

import base.Baseclass;
import pages.MergeLoginPage;

public class TC0004MergeLead extends Baseclass
{
	@Test
	public void runMergeLead() throws InterruptedException 
	{
		new MergeLoginPage(driver)
		.enterUserName()
		.enterPassword()
		.clickLoginButton()
		.clickcrmsfalink()
		.clickleadlink()
		.clickmergeleadlink()
		.Findmergeleads()
		.enterfirstname()
		.clickfindleads()
		.LeadID()
		.selectanotherlead()
		.entername()
		.clickfindleads()
		.secondlead()
		.leadsclick()
		.leadid()
		.findleadbutton()
		.msg();


	}
}
