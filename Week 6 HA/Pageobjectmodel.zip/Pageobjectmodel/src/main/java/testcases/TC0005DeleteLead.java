package testcases;

import org.testng.annotations.Test;
import base.Baseclass;
import pages.DeleteLoginPage;


public class TC0005DeleteLead extends Baseclass
{
	@Test
	public void runDeleteLead() throws InterruptedException 
	{
		new DeleteLoginPage(driver)
		.enterUserName()
		.enterPassword()
		.clickLoginButton()
		.clickcrmsfalink()
		.Clickleadslink()
		.findleads()
		.phonetab()
		.enterphonenumber()
		.clickfindleadsbutton()
		.leadid()
		.delete()
		.verifydeletedlead()
		.sendleadid()
		.findleadbutton()
		.msg();
	}
}
