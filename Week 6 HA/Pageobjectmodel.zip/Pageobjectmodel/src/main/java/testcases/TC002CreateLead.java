package testcases;
import org.testng.annotations.Test;
import base.Baseclass;
import pages.LoginPage;

public class TC002CreateLead extends Baseclass{

	@Test
	public void runCreateLead() {

		new LoginPage(driver)
		.enterUserName()
		.enterPassword()
		.clickLoginButton()
		.verifyHomePage()
		.clickCrmsfaLink()
		.clickLeadsLink()
		.clickCreateLead()
		.enterCompanyName()
		.enterFirstName()
		.enterLastName()
		.clickSubmitButton()
		.verifyCreateLead();




	}

}


