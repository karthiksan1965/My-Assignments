package testcases;


import base.Baseclass;
import org.testng.annotations.Test;
import pages.LoginPage;

public class TC001LoginPage extends Baseclass 
{
	@Test
	public void runlogin() 
	{

		new LoginPage (driver)

		.enterUserName()

		.enterPassword()

		.clickLoginButton()

		.verifyHomePage();




	}
}

