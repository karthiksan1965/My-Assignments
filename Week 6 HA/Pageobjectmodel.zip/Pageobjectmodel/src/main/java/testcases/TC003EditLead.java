package testcases;


import org.testng.annotations.Test;
import base.Baseclass;
import pages.EditLoginPage;


public class TC003EditLead extends Baseclass
{

	@Test
	public void runeditLead() throws InterruptedException 
	{

		new EditLoginPage(driver)
		.enterUserName()
		.enterPassword()
		.clickLoginButton()
		.clickcrmsfalink()
		.clickeditLead()
		.clickFindLeads()
		.clickphonetab()
		.enterphonenumber()
		.clickfindleads()
		.elementtoedit()
		.clickeditbutton()
		.details()
		.verifyLeadedited();






	}

}