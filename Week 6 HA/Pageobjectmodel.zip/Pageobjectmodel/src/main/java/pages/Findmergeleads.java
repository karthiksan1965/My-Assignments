package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import base.Baseclass;

public class Findmergeleads extends Baseclass

{
	public Findmergeleads(ChromeDriver driver)
	{
		this.driver=driver;

	}
	public Findmergeleads enterfirstname ()
	{
		driver.findElement(By.xpath("//input[@name='firstName']")).sendKeys("babu");
		return this;
	}
	public Findmergeleads clickfindleads () throws InterruptedException
	{
		driver.findElement(By.xpath("//button[text()='Find Leads']")).click();
		Thread.sleep(3000);
		return this;
	}

	public ToLead LeadID ()
	{
		String leadID = driver.findElement(By.xpath("//div[@class='x-grid3-cell-inner x-grid3-col-partyId']/a")).getText();
		driver.findElement(By.xpath("//div[@class='x-grid3-cell-inner x-grid3-col-partyId']/a")).click();
		Set<String> allWindows = driver.getWindowHandles();
		List<String> allhandles = new ArrayList<String>(allWindows);
		driver.switchTo().window(allhandles.get(0));
		return new ToLead (driver);

	}
}


