package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import base.Baseclass;

public class DeleteLeadSuccess extends Baseclass
{
	public DeleteLeadSuccess(ChromeDriver driver)
	{
		this.driver=driver;

	}

	public DeleteLeadSuccess verifydeletedlead ()
	{
		driver.findElement(By.linkText("Find Leads")).click();
		return this;
	}
	public DeleteLeadSuccess sendleadid()
	{
		driver.findElement(By.xpath("//input[@name='id']")).sendKeys("leadID");
		return this;
	}
	public DeletLeadVerify findleadbutton ()
	{
		driver.findElement(By.xpath("//button[text()='Find Leads']")).click();
		return new DeletLeadVerify (driver);
	}
}
