package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;
import base.Baseclass;

public class VerifyEditLead extends Baseclass
{
	public VerifyEditLead(ChromeDriver driver)
	{
		this.driver=driver;

	}
	public VerifyEditLead verifyLeadedited() 
	{
		String text = driver.findElement(By.id("viewLead_companyName_sp")).getText();
		{
			if (text.contains("TCS")) 
			{
				System.out.println("Lead is edited successfully");
			}
			else 
			{
				System.out.println("Lead is not edited");
			}
			return this;
		}
	}
}

