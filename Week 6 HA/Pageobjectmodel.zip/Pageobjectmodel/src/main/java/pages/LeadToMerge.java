package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import base.Baseclass;

public class LeadToMerge extends Baseclass

{
	public LeadToMerge (ChromeDriver driver)
	{
		this.driver=driver;

	}

	public LeadToMerge leadsclick()
	{
		driver.findElement(By.linkText("Find Leads")).click();
		return this;
	}
	public LeadToMerge leadid () throws InterruptedException
	{
		driver.findElement(By.xpath("//input[@name='id']")).sendKeys("leadID");
		Thread.sleep(3000);
		return this;
	}
	public VerifyMergeLead findleadbutton ()
	{
		driver.findElement(By.xpath("//button[text()='Find Leads']")).click();
		return new VerifyMergeLead (driver);
	}

}
