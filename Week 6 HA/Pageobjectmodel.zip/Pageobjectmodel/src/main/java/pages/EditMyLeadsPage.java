package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import base.Baseclass;

public class EditMyLeadsPage extends Baseclass
{
	public EditMyLeadsPage(ChromeDriver driver)
	{
		this.driver=driver;
	}

	public EditMyLeadsPage clickeditLead() 
	{
		driver.findElement(By.linkText("Leads")).click();
		return this;
	}

	public FindLeads clickFindLeads() 
	{
		driver.findElement(By.linkText("Find Leads")).click();
		return new FindLeads (driver);
	}
}
