package pages;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import base.Baseclass;

public class MergeLeads extends Baseclass
{
	public MergeLeads(ChromeDriver driver)
	{
		this.driver=driver;

	}

	public MergeLeads clickleadlink ()
	{
		driver.findElement(By.linkText("Leads")).click();
		return this;
	}
	public MergeLeads clickmergeleadlink ()
	{
		driver.findElement(By.linkText("Merge Leads")).click();
		return this;
	}
	public Findmergeleads Findmergeleads ()
	{
		driver.findElement(By.xpath("//img[@alt='Lookup']")).click();
		Set<String> allWindows = driver.getWindowHandles();
		List<String> allhandles = new ArrayList<String>(allWindows);
		driver.switchTo().window(allhandles.get(1));
		return new Findmergeleads (driver);

	}
}