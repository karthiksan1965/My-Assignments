package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import base.Baseclass;

public class LeadDelete extends Baseclass
{
	public LeadDelete(ChromeDriver driver)
	{
		this.driver=driver;

	}

	public LeadDelete leadid ()
	{
		String leadID = driver.findElement(By.xpath("//div[@class='x-grid3-cell-inner x-grid3-col-partyId']/a")).getText();
		driver.findElement(By.xpath("//div[@class='x-grid3-cell-inner x-grid3-col-partyId']/a")).click();
		return this;
	}
	public DeleteLeadSuccess delete ()
	{
		driver.findElement(By.linkText("Delete")).click();
		return new DeleteLeadSuccess (driver);

	}
}