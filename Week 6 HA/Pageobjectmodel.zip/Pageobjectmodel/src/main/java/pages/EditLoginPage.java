package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import base.Baseclass;

public class EditLoginPage extends Baseclass

{
	public EditLoginPage(ChromeDriver driver)
	{
		this.driver=driver;

	}
	public EditLoginPage enterUserName() 
	{
		driver.findElement(By.id("username")).sendKeys("Demosalesmanager");
		return this;
	}
	public EditLoginPage enterPassword() 
	{
		driver.findElement(By.id("password")).sendKeys("crmsfa");
		return this;
	}
	public EditLoginPage clickLoginButton() 
	{
		driver.findElement(By.className("decorativeSubmit")).click();

		return this;
	}
	public EditMyLeadsPage clickcrmsfalink ()
	{
		driver.findElement(By.linkText("CRM/SFA")).click();
		return new EditMyLeadsPage (driver);
	}

}


