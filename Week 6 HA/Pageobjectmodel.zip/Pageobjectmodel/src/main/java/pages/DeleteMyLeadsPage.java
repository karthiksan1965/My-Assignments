package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import base.Baseclass;

public class DeleteMyLeadsPage extends Baseclass
{
	public DeleteMyLeadsPage(ChromeDriver driver)
	{
		this.driver=driver;

	}
	public DeleteMyLeadsPage Clickleadslink()
	{
		driver.findElement(By.linkText("Leads")).click();
		return this;

	}
	public DeleteMyLeadsPage findleads()
	{
		driver.findElement(By.linkText("Find Leads")).click();
		return this;

	}
	public DeleteMyLeadsPage phonetab()
	{
		driver.findElement(By.xpath("//span[text()='Phone']")).click();
		return this;

	}
	public DeleteMyLeadsPage enterphonenumber()
	{
		driver.findElement(By.xpath("//input[@name='phoneNumber']")).sendKeys("99");
		return this;

	}


	public LeadDelete clickfindleadsbutton() throws InterruptedException
	{
		driver.findElement(By.xpath("//button[text()='Find Leads']")).click();
		Thread.sleep(2000);
		return new LeadDelete (driver);


	}
}
