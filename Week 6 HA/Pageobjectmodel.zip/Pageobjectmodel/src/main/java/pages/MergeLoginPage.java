package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import base.Baseclass;

public class MergeLoginPage extends Baseclass

{
	public MergeLoginPage(ChromeDriver driver)
	{
		this.driver=driver;

	}
	public  MergeLoginPage enterUserName() 
	{
		driver.findElement(By.id("username")).sendKeys("Demosalesmanager");
		return this;
	}
	public MergeLoginPage enterPassword() 
	{
		driver.findElement(By.id("password")).sendKeys("crmsfa");
		return this;
	}
	public MergeLoginPage clickLoginButton() 
	{
		driver.findElement(By.className("decorativeSubmit")).click();

		return this;
	}
	public MergeLeads clickcrmsfalink ()
	{
		driver.findElement(By.linkText("CRM/SFA")).click();
		return new MergeLeads(driver);
	}

}