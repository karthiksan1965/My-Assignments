package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import base.Baseclass;

public class ViewLead extends Baseclass
{
	public ViewLead(ChromeDriver driver)
	{
		this.driver=driver;
	}
	public ViewLead clickeditbutton()
	{
		driver.findElement(By.linkText("Edit")).click();
		return this;

	}
	public VerifyEditLead details()
	{
		WebElement companyName = driver.findElement(By.id("updateLeadForm_companyName"));
		companyName.clear();
		companyName.sendKeys("TCS");
		driver.findElement(By.name("submitButton")).click();
		return new VerifyEditLead(driver);

	}

}