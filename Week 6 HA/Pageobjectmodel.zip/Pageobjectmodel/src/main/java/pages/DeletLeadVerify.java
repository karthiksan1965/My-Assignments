package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import base.Baseclass;

public class DeletLeadVerify extends Baseclass
{
	public DeletLeadVerify(ChromeDriver driver)
	{
		this.driver=driver;

	}
	public DeletLeadVerify msg ()
	{
		String text = driver.findElement(By.xpath("//div[text()='No records to display']")).getText();

		if (text.equals("No records to display")) 
		{
			System.out.println("Lead deleted successfully");
		} 
		else 
		{
			System.out.println("Lead is not deleted ");
		}
		return this;
	}
}