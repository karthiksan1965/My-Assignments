package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;
import base.Baseclass;

public class DeleteLoginPage extends Baseclass

{
	public DeleteLoginPage(ChromeDriver driver)
	{
		this.driver=driver;

	}
	public DeleteLoginPage enterUserName() 
	{
		driver.findElement(By.id("username")).sendKeys("Demosalesmanager");
		return this;
	}
	public DeleteLoginPage enterPassword() 
	{
		driver.findElement(By.id("password")).sendKeys("crmsfa");
		return this;
	}
	public DeleteLoginPage clickLoginButton() 
	{
		driver.findElement(By.className("decorativeSubmit")).click();

		return this;
	}
	public DeleteMyLeadsPage clickcrmsfalink ()
	{
		driver.findElement(By.linkText("CRM/SFA")).click();
		return new DeleteMyLeadsPage (driver);
	}

}
