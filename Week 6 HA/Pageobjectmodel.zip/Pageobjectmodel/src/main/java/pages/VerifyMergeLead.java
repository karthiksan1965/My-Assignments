package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import base.Baseclass;

public class VerifyMergeLead extends Baseclass

{
	public VerifyMergeLead (ChromeDriver driver)
	{
		this.driver=driver;

	}


	public VerifyMergeLead msg() 
	{
		String text = driver.findElement(By.xpath("//div[text()='No records to display']")).getText();

		if (text.equals("No records to display")) 
		{
			System.out.println("Lead Merged successfully");
		} 
		else 
		{
			System.out.println("Lead is not merged ");
		}
		return this;
	}
}