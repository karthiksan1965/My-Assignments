package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import base.Baseclass;

public class Anotherlead extends Baseclass
{

	public Anotherlead (ChromeDriver driver)
	{
		this.driver=driver;

	}
	public Anotherlead entername ()
	{
		driver.findElement(By.xpath("//input[@name='firstName']")).sendKeys("hari");
		return this;
	}
	public AnotherMergeLead clickfindleads() throws InterruptedException
	{
		driver.findElement(By.xpath("//button[text()='Find Leads']")).click();
		Thread.sleep(1000);
		return new AnotherMergeLead (driver);
	}
}
