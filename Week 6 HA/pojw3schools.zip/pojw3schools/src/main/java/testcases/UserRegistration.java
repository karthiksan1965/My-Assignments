package testcases;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import base.BaseClass;
import pages.RegistrationDetails;


public class UserRegistration extends BaseClass
{

	@BeforeTest
	public void setValues() 
	{
		fileName="RegistrationDetails";

	}


	@Test(dataProvider = "fetchData")

	public void runuserregistration(String fname, String Email, String Address,String City,String State,String Zip,String ExpYear,String CVV,String ExpMonth,String Creditcardnumber,String NameonCard) 
	{

		new RegistrationDetails(driver)
		.enterintoframe()
		.enterFullName(fname)
		.enteremail(Email)
		.enteraddress(Address)
		.enterCity(City)
		.enterState(State)
		.enterZip(Zip)
		.enterExpYear(ExpYear)
		.enterCVV(CVV)
		.enterExpMonth(ExpMonth)
		.enterCreditcardnumber(Creditcardnumber)
		.enterNameonCard(NameonCard)
		.clickContinuetocheckoutButton()
		.verifyregdetails();
	}

}
