package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;
import base.BaseClass;


public class VerifyFormData extends BaseClass
{
	public VerifyFormData (ChromeDriver driver)
	{
		this.driver=driver;
	}


	public VerifyFormData verifyregdetails() 
	{
		String text = driver.findElement(By.tagName("h1")).getText();

		if (text.contains("Submitted")) 
		{
			System.out.println("Form Submitted Succesfully");
		}
		else 
		{
			System.out.println("Form not Submitted Succesfully");
		}
		return this;
	}
}