package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import base.BaseClass;

public class RegistrationDetails extends BaseClass
{
	public RegistrationDetails (ChromeDriver driver)
	{
		this.driver=driver;
	}

	public RegistrationDetails enterintoframe() 
	{
		driver.switchTo().frame("iframeResult");
		return this;

	}

	public RegistrationDetails enterFullName(String fname) 
	{
		driver.findElement(By.id("fname")).sendKeys(fname);
		return this;

	}

	public RegistrationDetails enteremail(String Email) 
	{
		driver.findElement(By.id("email")).sendKeys(Email);
		return this;

	}
	public RegistrationDetails enteraddress(String Address) 
	{
		driver.findElement(By.id("adr")).sendKeys(Address);
		return this;

	}

	public RegistrationDetails enterCity(String City) 
	{
		driver.findElement(By.id("city")).sendKeys(City);
		return this;

	}

	public RegistrationDetails enterState (String State ) 
	{
		driver.findElement(By.id("state")).sendKeys(State);
		return this;

	}

	public RegistrationDetails enterZip(String Zip) 
	{
		driver.findElement(By.id("zip")).sendKeys(Zip);
		return this;

	}
	public RegistrationDetails enterExpYear (String ExpYear ) 
	{
		driver.findElement(By.id("expyear")).sendKeys(ExpYear);
		return this;

	}


	public RegistrationDetails enterCVV (String CVV ) 
	{
		driver.findElement(By.id("cvv")).sendKeys(CVV);
		return this;

	}
	public RegistrationDetails enterExpMonth(String ExpMonth ) 
	{
		driver.findElement(By.id("expmonth")).sendKeys(ExpMonth);
		return this;

	}
	public RegistrationDetails enterCreditcardnumber(String Creditcardnumber ) 
	{
		driver.findElement(By.id("ccnum")).sendKeys(Creditcardnumber);
		return this;

	}

	public RegistrationDetails enterNameonCard(String NameonCard ) 
	{
		driver.findElement(By.id("cname")).sendKeys(NameonCard);
		return this;

	}


	public VerifyFormData clickContinuetocheckoutButton() 
	{
		driver.findElement(By.className("btn")).click();

		return new VerifyFormData(driver);

	}

}

