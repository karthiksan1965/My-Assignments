package runner;

import base.Baseclass;
import io.cucumber.testng.CucumberOptions;

@CucumberOptions(features={"src/test/java/Login.feature","src/test/java/MergeLead.feature","src/test/java/CreateLead.feature","src/test/java/EditLead.feature","src/test/java/DeleteLead.feature"},
glue={"pages"},
monochrome=true,
publish=true,
tags="@smoke or @sanity")

public class CucumberRunner extends Baseclass 
{

}
