package pages;

public @interface functional {

}
