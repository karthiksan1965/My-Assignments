
package pages;

import org.openqa.selenium.By;


import base.Baseclass;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;


public class CreateLead extends Baseclass
{
	@When("Click on crmsfa link")
	public void click_on_crmsfa_link() 
	{
		driver.findElement(By.partialLinkText("CRM")).click();
	}

	@When("Click on the leads link")
	public void click_on_the_leads_link() 
	{
		driver.findElement(By.linkText("Leads")).click();
	}

	@When("Click on the createLead link")
	public void click_on_the_create_lead_link() 
	{
		driver.findElement(By.linkText("Create Lead")).click();
	}

	@Given("Enter the companyname as TestLeaf")
	public void enter_the_companyname_as_test_leaf() 
	{
		driver.findElement(By.id("createLeadForm_companyName")).sendKeys("TestLeaf");
	}

	@Given("Enter the firstname  Subraja")
	public void enter_the_firstname_subraja() 
	{
		driver.findElement(By.id("createLeadForm_firstName")).sendKeys("Subraja");
	}

	@Given("Enter the lastname  S")
	public void enter_the_lastname_s() 
	{
		driver.findElement(By.id("createLeadForm_lastName")).sendKeys("S");
	}


	@When("Click on the submit button")
	public void click_on_the_submit_button() 
	{
		driver.findElement(By.name("submitButton")).click();
	}

	@Then("Leadid should be displayed as <companyname>")
	public void leadid_should_be_displayed_as_companyname() 
	{
		String text = driver.findElement(By.id("viewLead_companyName_sp")).getText();
		if (text.contains("TestLeaf")) {
			System.out.println("Lead Created Successfully");
		}
		else {
			System.out.println("Lead not Created Successfully");
		}
	}
}
