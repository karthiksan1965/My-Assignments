package pages;

import org.openqa.selenium.By;

import base.Baseclass;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class DeleteLead extends Baseclass
{
	@When("Click on the Delete link")
	public void click_on_the_delete_link() 
	{
		driver.findElement(By.linkText("Delete")).click();
	}

	@Then("Verify the lead is deleted and should be displayed as <No records to display>")
	public void verify_the_lead_is_deleted_and_should_be_displayed_as_no_records_to_display() 
	{
		String text = driver.findElement(By.className("x-paging-info")).getText();
		if (text.equals("No records to display")) 
		{
			System.out.println("Lead deleted successfully");
		} else 
		{
			System.out.println("Lead is not deleted ");
		}

	}

}
