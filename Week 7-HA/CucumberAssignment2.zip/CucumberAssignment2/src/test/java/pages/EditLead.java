package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import base.Baseclass;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class EditLead extends Baseclass
{
	@When("Click on the Find Leads link")
	public void click_on_the_find_leads_link() 
	{
		driver.findElement(By.linkText("Find Leads")).click();
	}

	@When("Click on the Phone Tab")
	public void click_on_the_phone_tab() 
	{
		driver.findElement(By.xpath("//span[text()='Phone']")).click(); 
	}

	@When("Enter the phoneNumber as {string}")
	public void enter_the_phone_number_as(String phNo) 
	{
		driver.findElement(By.xpath("//input[@name='phoneNumber']")).sendKeys("phNo");
	}

	@When("Click on the Find Leads link again")
	public void click_on_the_find_leads_link_again() throws InterruptedException 
	{
		driver.findElement(By.xpath("//button[text()='Find Leads']")).click();
		Thread.sleep(2000);
	}

	@When("Click on the Lead id to edit")
	public void click_on_the_lead_id_to_edit() 
	{
		driver.findElement(By.xpath("//div[@class='x-grid3-cell-inner x-grid3-col-partyId']/a")).click(); 
	}

	@When("Click on the edit button")
	public void click_on_the_edit_button() 
	{
		driver.findElement(By.linkText("Edit")).click();
	}   

	@When("Edit the Company details")
	public void edit_the_company_details() 
	{
		WebElement companyName = driver.findElement(By.id("updateLeadForm_companyName"));
		companyName.clear();
		companyName.sendKeys("TestLeaf");
	}

	@Then("verify the edited Leadid should be displayed as <companyname>")
	public void verify_the_edited_leadid_should_be_displayed_as_companyname() 
	{
		String text = driver.findElement(By.id("viewLead_companyName_sp")).getText();
		if (text.contains("TestLeaf")) 
		{
			System.out.println("Lead is edited Successfully");
		}
		else 
		{
			System.out.println("Lead is not edited");
		}

	}
}