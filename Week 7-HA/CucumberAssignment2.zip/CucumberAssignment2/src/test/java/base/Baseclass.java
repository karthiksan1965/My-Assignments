package base;

import org.openqa.selenium.chrome.ChromeDriver;

import io.cucumber.testng.AbstractTestNGCucumberTests;

public class Baseclass extends AbstractTestNGCucumberTests
{

	public static ChromeDriver driver;
}



