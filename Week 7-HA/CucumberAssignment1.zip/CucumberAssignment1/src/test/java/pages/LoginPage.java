package pages;

import org.openqa.selenium.By;

import base.Baseclass;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class LoginPage extends Baseclass
{
	@Given("Enter the username as {string}")
	public void enter_the_username_as(String uName) 
	{
		driver.findElement(By.id("username")).sendKeys(uName);
	}

	@Given("Enter the password as {string}")
	public void enter_the_password_as(String pWord) 
	{
		driver.findElement(By.id("password")).sendKeys(pWord);
	}

	@When("Click on the Login Button")
	public void click_on_the_login_button() 
	{
		driver.findElement(By.className("decorativeSubmit")).click();
	}

	@Then("HomePage should be displayed")
	public void home_page_should_be_displayed() 
	{
		String text = driver.findElement(By.tagName("h2")).getText();
		if (text.contains("Welcome")) 
		{
			System.out.println("Home page is displayed");
		}
		else 

		{
			System.out.println("Home page is not displayed");
		}
	}
}


