package pages;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import base.Baseclass;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class MergeLead extends Baseclass
{
	@When("Click on the Merge Leads link")
	public void click_on_the_merge_leads_link() 
	{
		driver.findElement(By.linkText("Merge Leads")).click();

	}

	@When("Click on the From Lead image icon")
	public void click_on_the_from_lead_image_icon() throws InterruptedException 
	{
		driver.findElement(By.xpath("//img[@alt='Lookup']")).click();
		Thread.sleep(3000);
		Set<String> allWindows = driver.getWindowHandles();
		List<String> allhandles = new ArrayList<String>(allWindows);
		driver.switchTo().window(allhandles.get(1));

	}

	@Given("Enter the firstname as (.*)$")
	public void enter_the_firstname(String fName) 
	{
		driver.findElement(By.xpath("//input[@name='firstName']")).sendKeys(fName);
	}

	@Given("Click on the Find Leads button")
	public void click_on_the_find_leads_button() throws InterruptedException 
	{
		driver.findElement(By.xpath("//button[text()='Find Leads']")).click();
		Thread.sleep(1000);
	}


	@When("Click on the Lead id link")
	public void click_on_the_lead_id_link() 
	{

		String leadID = driver.findElement(By.xpath("//div[@class='x-grid3-cell-inner x-grid3-col-partyId']/a")).getText();
		driver.findElement(By.xpath("//div[@class='x-grid3-cell-inner x-grid3-col-partyId']/a")).click();
		Set<String> allWindows = driver.getWindowHandles();
		List<String> allhandles = new ArrayList<String>(allWindows);
		driver.switchTo().window(allhandles.get(0));

	}

	@When("Click on the To Lead image icon")
	public void click_on_the_to_lead_image_icon() throws InterruptedException 
	{
		driver.findElement(By.xpath("(//img[@alt='Lookup'])[2]")).click();
		Set<String> allWindows2 = driver.getWindowHandles();
		List<String> allhandles2 = new ArrayList<String>(allWindows2);
		driver.switchTo().window(allhandles2.get(1));
		Thread.sleep(1000);


	}










	@When("Click on the Merge link")
	public void click_on_the_merge_link() throws InterruptedException 
	{


		driver.findElement(By.linkText("Merge")).click();
		driver.switchTo().alert().accept();

	}

	@When("Enter the Lead id")
	public void enter_the_lead_id() throws InterruptedException 
	{
		driver.findElement(By.xpath("//input[@name='id']")).sendKeys("leadID");
		Thread.sleep(3000);


	}





	@Then("Verify the lead is merged lead should be displayed as <No records to display>")
	public void verify_the_lead_is_merged_lead_should_be_displayed_as_no_records_to_display() 
	{
		String text = driver.findElement(By.className("x-paging-info")).getText();
		if (text.equals("No records to display")) 
		{
			System.out.println("Lead Merged Successfully");
		} else 
		{
			System.out.println("Lead not Merged Successfully");
		}
	}

}


