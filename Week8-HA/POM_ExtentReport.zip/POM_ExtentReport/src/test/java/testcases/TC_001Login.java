package testcases;

import java.io.IOException;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.BaseClass;
import pages.LoginPage;

public class TC_001Login extends BaseClass{
	
	@BeforeTest
	public void setValues() {
		fileName="Login";
		testName="Login";
		testDescription="Login with multiple credentials";
		testAuthor="Subraja";
		testCategory="smoke";
	}
	
	
	@Test(dataProvider = "fetchData")
	public void runLogin(String uName,String pWord) throws IOException {
		
		new LoginPage()
		.enter_the_username(uName)
		.enter_the_password(pWord)
		.click_on_the_login_button()
		.home_page_should_be_displayed();

	}

}
