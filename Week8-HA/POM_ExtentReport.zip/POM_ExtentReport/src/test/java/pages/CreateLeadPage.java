package pages;

import org.openqa.selenium.By;
import base.BaseClass;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.When;

public class CreateLeadPage extends BaseClass{


	@Given("Enter the companyname as (.*)$")
	public CreateLeadPage enter_the_companyname(String cName) {
		getDriver().findElement(By.id("createLeadForm_companyName")).sendKeys(cName);
		return this;
	}

	@Given("Enter the firstname as (.*)$")
	public CreateLeadPage enter_the_firstname(String fName) {
		getDriver().findElement(By.id("createLeadForm_firstName")).sendKeys(fName);
		return this;
	}

	@Given("Enter the lastname as (.*)$")
	public CreateLeadPage enter_the_lastname(String lName) {
		getDriver().findElement(By.id("createLeadForm_lastName")).sendKeys(lName);
		return this;
	}

	@When("Click on the submit button")
	public ViewLeadsPage click_on_the_submit_button() throws InterruptedException 
	{
		getDriver().findElement(By.name("submitButton")).click();

		return new ViewLeadsPage();
	}

}
