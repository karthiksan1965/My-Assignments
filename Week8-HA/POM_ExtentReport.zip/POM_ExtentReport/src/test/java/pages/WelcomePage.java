package pages;

import org.openqa.selenium.By;

import base.BaseClass;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class WelcomePage extends BaseClass{
	
	@Then("HomePage should be displayed")
	public WelcomePage home_page_should_be_displayed() {
		String text = getDriver().findElement(By.tagName("h2")).getText();
		if (text.contains("Welcome")) {
			System.out.println("HomePage is displayed");
		}
		else {
			System.out.println("Homepage is not displayed");
		}
		return this;
	}
	

	@When("Click on crmsfa link")
	public MyHomePage click_on_crmsfa_link() {
		getDriver().findElement(By.partialLinkText("CRM")).click();
		return new MyHomePage();
	}

}
