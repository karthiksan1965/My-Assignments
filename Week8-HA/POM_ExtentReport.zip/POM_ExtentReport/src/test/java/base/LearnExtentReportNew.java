package base;

import java.io.IOException;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;

public class LearnExtentReportNew 
{

	public static void main(String[] args) throws IOException 
	{

		// step 1 : Set up the path of the report folder
		ExtentHtmlReporter reporter = new ExtentHtmlReporter("./reports/result.html");

		// step 2: Create object for ExtentReports
		ExtentReports extent = new ExtentReports();

		// step 3: attach the data with the physical file
		extent.attachReporter(reporter);


		//step 4: Create testcases and assign the details
		// testcasename, testdescription
		ExtentTest test = extent.createTest("Login","Login with valid credentials");
		test.assignCategory("smoke");
		test.assignAuthor("Subraja");

		ExtentTest test1 = extent.createTest("CreateLead","Login with multiple credentials and createlead");
		test.assignCategory("smoke");
		test.assignAuthor("Subraja");


		// step 5: Step level status
		test.pass("Username is entered successfully",MediaEntityBuilder.createScreenCaptureFromPath(".././snaps/leaftaps.png").build());
		test.pass("Password is entered successfully");
		test.pass("Login is done successfully");

		test1.pass("Username is entered successfully",MediaEntityBuilder.createScreenCaptureFromPath(".././snaps/leaftaps1.png").build());
		test1.pass("Password is entered successfully");
		test1.pass("Login is done successfully");
		test1.pass("Click on the leads link");
		test1.pass ("Click on the createLead link");
		test1.pass("Enter the companyname");
		test1.pass("Enter the firstname");
		test1.pass("Enter the lastname");
		test1.pass("Click on the submit button");
		test1.pass("Leadid should be displayed");



		// Mandatory step
		extent.flush();

		System.out.println("Done");




	}

}

