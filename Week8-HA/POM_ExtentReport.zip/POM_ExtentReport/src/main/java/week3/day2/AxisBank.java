package week3.day2;

public class AxisBank implements RBI,Payments{

	@Override
	public void knowYourCustomer() {
		System.out.println("PAN CARD");
		
	}

	public int withDrawalLimit() {
		// TODO Auto-generated method stub
		return 50000;
	}

	public void repoRate() {
		// TODO Auto-generated method stub
		
	}

	public void UpiPayments() {
		// TODO Auto-generated method stub
		
	}
	
	

}
