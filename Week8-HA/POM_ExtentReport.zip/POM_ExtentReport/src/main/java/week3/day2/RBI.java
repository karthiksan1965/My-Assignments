package week3.day2;

public interface RBI {
	
	void knowYourCustomer();

	int withDrawalLimit();
	
	void repoRate();
	

}
